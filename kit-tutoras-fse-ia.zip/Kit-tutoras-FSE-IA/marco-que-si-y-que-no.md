# Qué sí y qué no se puede hacer en la tutoría

| Sí se puede | No se puede |
|---|---|
| Preparar casos clínicos ficticios, preguntas y rúbricas | Introducir datos de pacientes, aunque se quite el nombre |
| Pedir un guion para una entrevista tutora-residente | Introducir evaluaciones, informes o incidencias de residentes |
| Organizar un calendario con iniciales o nombres ficticios | Dejar que la IA califique o decida una evaluación |
| Usar Copilot con la cuenta del hospital | Usar cuentas personales o herramientas no autorizadas con información del centro |
| Buscar y resumir literatura, comprobando las fuentes | Citar una referencia sin comprobar que existe |
| Decir a las residentes cuándo un material está hecho con IA | Cargar protocolos o documentos internos en un agente sin permiso |

## Tres marcos

### Reglamento europeo de IA (UE 2024/1689)

**Alfabetización en IA desde el 2 de febrero de 2025.** El Ómnibus digital (Reglamento UE 2026/1744) reformula esa obligación desde el 27 de julio de 2026 y aplaza las de alto riesgo al 2 de diciembre de 2027 y al 2 de agosto de 2028. La educación y la formación profesional figuran entre los ámbitos de alto riesgo cuando la IA se usa para evaluar resultados de aprendizaje.

**Qué significa para una tutora:** Formarse en IA forma parte del trabajo. La IA prepara material; no califica ni decide una evaluación.

### RGPD y LOPDGDD

**Los datos de salud son categoría especial (artículo 9).** Quitar el nombre no anonimiza: edad, fecha, unidad y diagnóstico juntos pueden identificar a una persona. Las evaluaciones y los informes de residentes también son datos personales.

**Qué significa para una tutora:** Ni datos de pacientes ni de residentes en el chat. En docencia, casos inventados.

### Estrategia de IA del Sistema Nacional de Salud

**Aprobada por el Consejo Interterritorial el 12 de noviembre de 2025.** Principios: fiabilidad, utilidad, humanización y universalidad. La formación de profesionales es uno de sus cinco objetivos. Inversión comunicada por el Ministerio: 223 millones de euros.

**Qué significa para una tutora:** Lo que hacemos hoy es lo que el propio sistema sanitario nos pide.

Datos contrastados el 16-11-2026.

## Quiero crear un agente o una aplicación en el hospital

Consulta el Espai IA de la intranet (https://pssjd.sharepoint.com/sites/UTI_ParcSanitari/OrganServ/IA/SitePages/Home.aspx), sección «Política. Normatives. Procediments». Preguntas que conviene llevar resueltas:

1. A quién dirijo la petición
2. Qué información tengo que aportar
3. Quién valida la protección de datos
4. Quién valida la seguridad
5. Plazos

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
