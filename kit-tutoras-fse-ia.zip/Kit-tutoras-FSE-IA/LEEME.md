# Carpeta de recursos: Inteligencia artificial en la docencia de residentes

Jornada de tutoras y tutores de Formación Sanitaria Especializada. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu.

Todo lo que se vio en la charla, en documentos sueltos para copiar y pegar. La herramienta es Microsoft Copilot con la cuenta del hospital.

## Las tres reglas

1. **Sin datos identificables.** Ni de pacientes ni de residentes. Quitar el nombre no basta.
2. **Verificar siempre.** La IA propone; la tutora comprueba con su criterio y con las fuentes.
3. **Declarar y decidir.** Decimos cuándo un material está hecho con IA. La evaluación la firma una persona.

## Qué hay en la carpeta

| Carpeta | Qué contiene |
|---|---|
| `1-agentes` | Los cuatro agentes: nombre, descripción, instrucciones e indicaciones de inicio. Cómo crearlos y compartirlos. |
| `2-paciente-simulado` | Seis conversaciones para ensayar, la rúbrica de la observadora, una guía de uso con residentes y una conversación real de ejemplo. |
| `3-cuadernos` | Dos cuadernos: fuentes, instrucciones y preguntas. Qué licencia hace falta y qué alternativa hay. |
| `4-gestion-y-automatizaciones` | Plantilla de la lista de rotaciones (CSV ficticio), sus columnas y tres flujos paso a paso con las plantillas de correo. |
| `5-prompts` | Biblioteca de prompts de docencia, evidencia y gestión. |
| `6-evidencia-y-verificacion` | Los cuatro pasos, las herramientas con sus enlaces y el protocolo para comprobar una referencia. |
| `7-habilidades` | Tres habilidades listas para cargar en un agente (paquetes .zip con un archivo SKILL.md). |
| `marco-que-si-y-que-no.md` | Las seis parejas de ejemplos y los tres marcos normativos. |

## Empezar en diez minutos

1. Abre Copilot con la cuenta del hospital: https://m365.cloud.microsoft/chat
2. Crea tu primer agente con `1-agentes/COMO-CREAR-UN-AGENTE.md` y las instrucciones de `1-agentes/agente-1-casos-y-docencia.md`.
3. Pídele un caso para tu especialidad y localiza un punto que haya que verificar.
4. Comprueba ese punto con `6-evidencia-y-verificacion/protocolo-de-verificacion.md`.

## Ideas para llevarnos

1. La IA ayuda a preparar la docencia; evaluar y decidir sigue siendo nuestro.
2. Las tres reglas: sin datos identificables, verificar siempre, declarar y decidir.
3. Copilot es la herramienta autorizada, y el Espai IA es la puerta para cualquier idea de agente o aplicación.
4. Una respuesta con referencias no es una respuesta verificada.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
