# Cómo crear y compartir un agente en Copilot

Pasos tal como se ven en el Copilot del PSSJD el 16-11-2026, con la licencia «Copilot Chat (Básico)». Los nombres de los menús pueden cambiar.

1. En Copilot: «Agentes» y «Nuevo agente».
2. «Omitir» para configurarlo a mano, o describirlo en el chat.
3. Nombre (máximo 30 caracteres), descripción e instrucciones (hasta 8.000 caracteres).
4. Indicaciones sugeridas: título y mensaje. Opcional: habilidades y conocimiento.
5. «Crear» y después «Compartir».

## Compartir

Un agente nace privado. Para que lo use otra persona hay que activar, en «Compartir», el uso compartido en toda la organización y pasarle el vínculo de chat.

Antes de compartir un agente con otras personas del hospital, consulta el circuito del Espai IA (https://pssjd.sharepoint.com/sites/UTI_ParcSanitari/OrganServ/IA/SitePages/Home.aspx), sección «Política. Normatives. Procediments».

## Qué permite la licencia básica

- Crear agentes con instrucciones, indicaciones de inicio y habilidades: disponible.
- Conocimiento de un agente: solo enlaces a páginas web públicas.
- Cuadernos: la sección existe, pero no deja crear cuadernos. Hace falta la licencia completa de Microsoft 365 Copilot.
- Compartir un agente con toda la organización: es un interruptor en «Compartir». Está apagado en los cuatro agentes.

## Habilidades

Un agente puede llevar además habilidades: paquetes .zip con un archivo SKILL.md que le enseñan una tarea concreta y se pueden reutilizar en otros agentes. En `7-habilidades` hay tres paquetes listos: en el agente, «Habilidades», «Agregar» y «Cargar».

## Si no puedes crear agentes

Si el agente no se abre: copiad sus instrucciones y pegadlas al inicio de una conversación normal de Copilot. Después escribid vuestra petición.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
