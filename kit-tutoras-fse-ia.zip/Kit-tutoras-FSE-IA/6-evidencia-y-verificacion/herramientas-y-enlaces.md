# De la duda del caso a la evidencia

## Cuatro pasos

1. **Preguntar.** Copilot convierte la duda en una pregunta PICO y propone términos de búsqueda.
2. **Buscar.** En fuentes de evidencia, no en el chat: PubMed, Epistemonikos, Cochrane, Consensus.
3. **Comprobar.** Que la referencia existe (PMID o DOI) y que dice lo que la IA afirma.
4. **Valorar.** Lectura crítica con una plantilla CASPe. La conclusión es nuestra.

## Herramientas

| Para qué | Herramienta | Nota | Enlace |
|---|---|---|---|
| Buscar estudios | PubMed | Gratuito. La fuente de referencia | https://pubmed.ncbi.nlm.nih.gov/ |
| Respuesta rápida con estudios enlazados | Consensus | Plan gratuito con límites | https://consensus.app/ |
| Tabla comparativa de estudios | Elicit | Plan gratuito básico | https://elicit.com/ |
| Revisiones sistemáticas | Epistemonikos | Evidencia sintetizada | https://www.epistemonikos.org/es/ |
| Revisiones sistemáticas | Biblioteca Cochrane | Evidencia sintetizada | https://www.cochranelibrary.com/ |
| Guías en español | GuíaSalud | Guías del SNS | https://portal.guiasalud.es/ |
| Lectura crítica | Plantillas CASPe | En español | https://redcaspe.org/materiales/ |

- OpenEvidence no está disponible en la Unión Europea desde el 30 de abril de 2026.
- La biblioteca del centro es el recurso para una búsqueda exhaustiva.

Son herramientas externas, sin cuenta institucional: solo con contenido bibliográfico y docente, nunca con datos del centro.

## Presentaciones

Gamma (https://gamma.app/): pegar el caso revisado, revisar el esquema que propone, generar las diapositivas, revisar el contenido antes de proyectarlo. No es una herramienta institucional. Solo contenido docente, sin datos de pacientes ni de residentes. Lo generado se revisa.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
