# Herramientas fuera de Copilot: evidencia y difusión

Herramientas externas, sin cuenta institucional. Solo con contenido bibliográfico y docente. Nunca con datos del centro, de pacientes ni de residentes. Lo que generan se revisa igual que lo demás.

## Las seis herramientas de la charla

| Herramienta | Para qué | Qué hace | Enlace |
|---|---|---|---|
| Consensus | Evidencia | Respuesta rápida a una pregunta, con los estudios enlazados para abrirlos y comprobarlos. | https://consensus.app/ |
| Elicit | Evidencia | Tabla comparativa de varios estudios, con las columnas que elijas. | https://elicit.com/ |
| e-videncIA | Evidencia | Asistente para práctica basada en la evidencia: pregunta estructurada, ecuación de búsqueda y PMID comprobados. GPT de la ponente, en ChatGPT. | https://chatgpt.com/g/g-68b9769816f88191a28bcd56db9301de-e-videncia |
| NotebookLM | Tus documentos | Responde solo a partir de los documentos que subes y señala de dónde sale cada afirmación. | https://notebooklm.google.com/ |
| Gamma | Difusión | Del caso revisado a las diapositivas de la sesión clínica. | https://gamma.app/ |
| FigureLabs | Difusión | Figuras e ilustraciones científicas para una sesión o un póster. | https://www.figurelabs.ai/ |

## Más fuentes de evidencia

| Para qué | Fuente | Nota | Enlace |
|---|---|---|---|
| Buscar estudios | PubMed | Gratuito. La fuente de referencia | https://pubmed.ncbi.nlm.nih.gov/ |
| Revisiones sistemáticas | Epistemonikos | Evidencia sintetizada | https://www.epistemonikos.org/es/ |
| Revisiones sistemáticas | Biblioteca Cochrane | Evidencia sintetizada | https://www.cochranelibrary.com/ |
| Guías en español | GuíaSalud | Guías del SNS | https://portal.guiasalud.es/ |
| Lectura crítica | Plantillas CASPe | En español | https://redcaspe.org/materiales/ |

- OpenEvidence no está disponible en la Unión Europea desde el 30 de abril de 2026.
- La biblioteca del centro es el recurso para una búsqueda exhaustiva.

## De la duda a la evidencia en cuatro pasos

1. **Preguntar.** Copilot convierte la duda en una pregunta PICO y propone términos de búsqueda.
2. **Buscar.** En fuentes de evidencia, no en el chat: PubMed, Epistemonikos, Cochrane, Consensus.
3. **Comprobar.** Que la referencia existe (PMID o DOI) y que dice lo que la IA afirma.
4. **Valorar.** Lectura crítica con una plantilla CASPe. La conclusión es nuestra.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
