# Prompts: Docencia

Para pegar en Copilot con la cuenta del hospital. Sustituye los corchetes por tu caso, siempre sin datos reales.

## Caso clínico por fases (siete elementos)

```
Actúa como docente de [especialidad].
Prepara un caso clínico para una residente de [R1 a R5].
Objetivo: que trabaje [tema] según el programa oficial de la especialidad.
Formato: caso en tres fases (presentación, evolución y desenlace).
Añade dos preguntas de razonamiento por fase, con la respuesta esperada.
Termina con una rúbrica de cuatro criterios y con una lista de puntos que debo verificar (dosis, pruebas, recomendaciones de guías).
Límite: paciente ficticio, sin datos reales, y dilo al principio.
```

## Revisar un caso antes de llevarlo a sesión

```
Revisa este caso clínico ficticio como si fueras una tutora exigente:
1. ¿Es clínicamente coherente de principio a fin?
2. ¿Qué dosis, pruebas o recomendaciones tengo que comprobar en una guía vigente?
3. ¿La dificultad corresponde a una residente de [año]?
4. ¿Hay estereotipos en cómo se describe a la persona atendida?
No corrijas el caso: dame una lista de dudas para que yo las compruebe.

[pega aquí el caso]
```

## Adaptar un caso a otro año de residencia

```
Adapta este caso clínico ficticio para una residente de [año]. Mantén el tema, cambia la complejidad y explícame en tres líneas qué has cambiado y por qué.

[pega aquí el caso]
```

## Preguntas de repaso con explicación

```
Genera diez preguntas de repaso sobre [tema] para una residente de [año] de [especialidad]. Para cada una: pregunta, respuesta correcta, por qué es correcta y un error frecuente. No cites referencias: dime qué tendría que comprobar yo.
```

## Guion de entrevista tutora-residente

```
Prepara un guion para la entrevista trimestral con una residente de [año]. Bloques: cómo está, qué ha aprendido en la rotación, dificultades, objetivos para el próximo trimestre y acuerdos. Preguntas abiertas, sin juicios. Deja espacio para anotar los acuerdos. No incluyas datos de ninguna persona.
```

## Estructura para dar feedback

```
Dame una estructura breve para dar feedback a una residente después de una sesión clínica: qué observar, cómo empezar por su autoevaluación, cómo formular dos puntos fuertes y dos de mejora con ejemplos de frases, y cómo cerrar con un acuerdo. Es una guía genérica: no voy a darte datos de nadie.
```

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
