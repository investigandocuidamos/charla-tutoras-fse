# Prompts: Gestión de la tutoría

Para pegar en Copilot con la cuenta del hospital. Sustituye los corchetes por tu caso, siempre sin datos reales.

## Calendario de rotaciones

```
Reparte a 4 residentes (R1-A, R1-B, R2-A, R2-B) en 3 unidades ([unidad 1], [unidad 2], [unidad 3]) durante 12 semanas, sin que coincidan dos en la misma unidad y con una semana de solapamiento en cada cambio. Preséntalo en tabla y dime qué conflictos has encontrado.
```

## Fechas de las cuatro entrevistas

```
El curso va del [fecha] al [fecha]. Propón las fechas de las cuatro entrevistas tutora-residente, una por trimestre, evitando [periodos que no valen]. Redacta la convocatoria con corchetes para lo que tengo que completar.
```

## Correo de bienvenida a la rotación

```
Escribe el correo de bienvenida a una rotación en [unidad]: horario, lugar y hora del primer día, persona de referencia y tres objetivos. Tono cercano. Deja entre corchetes todos los datos personales: los completo yo fuera del chat.
```

## Aviso a la unidad que recibe a una residente

```
Redacta un correo breve para la unidad que recibe a una residente de [año] de [especialidad] del [fecha] al [fecha]: objetivos de la rotación, persona de contacto en la unidad docente y qué necesito que me confirmen. Usa el código [R2-A] en lugar del nombre.
```

## Plantilla de acta de entrevista

```
Prepara una plantilla vacía de acta de entrevista tutora-residente: fecha, asistentes, temas tratados, acuerdos, responsables y fecha de la próxima entrevista. Solo la plantilla, con corchetes. No voy a darte datos de nadie.
```

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
