# Prompts: Evidencia

Para pegar en Copilot con la cuenta del hospital. Sustituye los corchetes por tu caso, siempre sin datos reales.

## De la duda a la pregunta PICO

```
Actúa como documentalista clínica. Tengo esta duda surgida de un caso clínico ficticio:

[escribe aquí la duda]

1. Conviértela en una pregunta PICO (paciente o problema, intervención, comparación, resultado).
2. Propón términos de búsqueda en inglés y en español, con sinónimos y términos MeSH si los conoces.
3. Escribe una estrategia de búsqueda para PubMed.

No me des referencias bibliográficas: las buscaré yo en PubMed, Epistemonikos o Cochrane.
```

## Lectura crítica con una plantilla CASPe

```
Te pego el resumen y los métodos de un artículo que he localizado y abierto yo. Aplica la plantilla CASPe para [ensayo clínico, revisión sistemática, estudio de cohortes...]: responde a cada pregunta con sí, no o no se puede saber, y señala la frase del texto en la que te basas. La conclusión sobre si lo aplico la saco yo.

[pega aquí el texto]
```

## Guion de sesión bibliográfica

```
Con este artículo que he leído, prepara un guion de sesión bibliográfica de 20 minutos para residentes: pregunta clínica, por qué importa, método en tres frases, resultado principal, dos limitaciones y tres preguntas para debatir. Indica en qué parte del texto está cada dato.

[pega aquí el resumen o el texto]
```

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
