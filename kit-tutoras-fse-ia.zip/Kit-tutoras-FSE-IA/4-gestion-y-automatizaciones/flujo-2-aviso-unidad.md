# Flujo 2: Aviso a la unidad que recibe a una residente

**Nivel:** Medio: Power Automate

Que la persona referente de la unidad reciba, siete días antes, un correo con quién llega, cuándo y con qué objetivos.

## Pasos

1. En Power Automate, crea un «flujo de nube programado» que se repita cada día a las 8:00.
2. Añade la acción de SharePoint «Obtener elementos» sobre la lista, con el filtro: Fecha de inicio igual a hoy más 7 días y Estado igual a Planificada.
3. Dentro de un «Aplicar a cada uno», añade «Enviar un correo electrónico (V2)» al campo «Referente de la unidad», con la plantilla de abajo.
4. Añade «Actualizar elemento» para poner el Estado en «Avisada». Así no se repite el correo.
5. Pruébalo primero con tu propia dirección como referente y con filas ficticias.

## Plantilla del correo

```
Asunto: Rotación en [Unidad de destino]: llega [Título] el [Fecha de inicio]

Hola,

El [Fecha de inicio] empieza su rotación en [Unidad de destino] la residente [Título] ([Año], [Especialidad]). Estará hasta el [Fecha de fin].

Objetivos de la rotación según su programa formativo:
[Objetivos de la rotación]

Si hay algún cambio de horario o de persona de referencia, respóndeme a este correo.

Gracias por acogerla.
[Tutora]
```

## Antes de activarlo

Un flujo que envía correos a otras personas es una automatización del centro: antes de activarlo, consúltalo por el circuito del Espai IA o con Sistemas de Información.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
