# Flujo 1: Aviso a la tutora cuando cambia la lista

**Nivel:** Fácil: sin salir de Lists

Que la tutora reciba un correo cada vez que alguien añade o cambia una rotación.

## Pasos

1. Abre la lista y pulsa los tres puntos de la barra superior. Elige «Flujos de trabajo».
2. Se abre una ventana con plantillas (en inglés). Elige «Alert me for SharePoint item or file updates».
3. Acepta las conexiones con tu cuenta del hospital y crea el flujo.
4. En esa misma ventana puedes describir con tus palabras lo que quieres automatizar, o empezar de cero con «Build from scratch».
5. El aviso te llega a ti. Para avisar a otra persona unos días antes de una fecha, usa el flujo siguiente.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
