# Flujo 3: Resumen semanal de rotaciones para la tutora

**Nivel:** Medio: Power Automate

Recibir cada lunes una tabla con quién está rotando, dónde, y qué rotaciones y entrevistas vienen en los próximos 14 días.

## Pasos

1. Crea un «flujo de nube programado» semanal: lunes a las 8:00.
2. Añade «Obtener elementos» con el filtro: Estado igual a En curso, o Fecha de inicio dentro de los próximos 14 días.
3. Añade «Crear tabla HTML» con las columnas Título, Unidad de destino, Fecha de inicio, Fecha de fin y Entrevista de seguimiento.
4. Añade «Enviar un correo electrónico (V2)» a ti misma con la tabla en el cuerpo.

## Plantilla del correo

```
Asunto: Rotaciones de la semana

Rotaciones en curso y próximas (14 días):

[Tabla generada por el flujo]

Entrevistas de seguimiento de esta semana: [lista]
```

## Antes de activarlo

Solo logística: fechas y unidades. Nada de evaluaciones, informes ni incidencias en correos automáticos.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
