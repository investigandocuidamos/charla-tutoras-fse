# Pedir a Copilot que te guíe para montar el flujo

Pega este texto en Copilot. Te explicará paso a paso qué acciones añadir en Power Automate.

```
Quiero un flujo de Power Automate sobre una lista de Microsoft Lists llamada "FSE · Rotaciones". Columnas: Título (código de la residente), Unidad de destino, Referente de la unidad (persona), Fecha de inicio, Fecha de fin, Objetivos de la rotación, Estado.

El flujo debe ejecutarse cada día a las 8:00, buscar las filas cuya Fecha de inicio sea dentro de 7 días y cuyo Estado sea "Planificada", enviar un correo a la persona de "Referente de la unidad" con los datos de la rotación y cambiar el Estado a "Avisada".

Explícame paso a paso qué acciones añadir y qué escribir en cada campo, incluido el filtro de fechas.
```

Solo logística: ni evaluaciones ni incidencias en correos automáticos. Un aviso automático a otras personas se activa con el visto bueno del centro.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
