# La lista de rotaciones en Microsoft Lists

Una tabla compartida con las rotaciones previstas. De ella salen los avisos automáticos. Solo logística: ni evaluaciones ni incidencias.

## Crearla desde la plantilla

1. Abre Microsoft Lists con la cuenta del hospital.
2. «Crear nuevo» y «Desde CSV». Sube `lista-rotaciones-plantilla.csv`.
3. Revisa el tipo de cada columna (tabla de abajo) y crea la lista.
4. Sustituye las filas ficticias por las rotaciones de tu unidad docente.

## Columnas

| Columna | Tipo | Para qué |
|---|---|---|
| Título | Texto | Código de la residente: R1-A, R2-B. Sin nombres si la lista se comparte fuera de la unidad docente. |
| Año | Opción | R1 a R5 |
| Especialidad | Texto |  |
| Unidad de destino | Texto |  |
| Referente de la unidad | Persona | Quién recibe el aviso |
| Fecha de inicio | Fecha | De ella dependen los avisos |
| Fecha de fin | Fecha |  |
| Objetivos de la rotación | Varias líneas de texto | Los del programa oficial |
| Entrevista de seguimiento | Fecha | Para el recordatorio a la tutora |
| Estado | Opción | Planificada, Avisada, En curso, Finalizada |

Las filas de la plantilla son ficticias.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
