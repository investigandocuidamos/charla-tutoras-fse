# Rúbrica de la observadora

Para dar feedback formativo después del ensayo. No es una nota ni un instrumento de evaluación.

| Criterio | Por mejorar | Adecuado | Destacado |
|---|---|---|---|
| Acogida y presentación | No se presenta o empieza por la pantalla | Se presenta y explica para qué es la conversación | Se presenta, pregunta cómo quiere que le llamen y cuida el entorno |
| Escucha y preguntas abiertas | Encadena preguntas cerradas e interrumpe | Combina preguntas abiertas y cerradas y deja terminar | Pregunta en abierto, resume lo escuchado y lo comprueba |
| Empatía y manejo de emociones | Pasa por alto la emoción o la corrige | Nombra la emoción y la valida | Valida, sostiene el silencio y adapta el ritmo a la persona |
| Información clara y sin tecnicismos | Usa jerga o da demasiada información de golpe | Explica con lenguaje llano y por partes | Explica por partes y pide a la persona que lo cuente con sus palabras |
| Cierre con acuerdo | Termina sin plan ni próximos pasos | Resume y propone el siguiente paso | Acuerda el siguiente paso, comprueba dudas y deja una vía de contacto |

## Cómo dar el feedback

1. Primero pregunta a la residente qué cree que ha ido bien y qué cambiaría.
2. Señala dos cosas que han funcionado, con la frase literal.
3. Señala dos cosas a mejorar, con una alternativa de cómo decirlo.
4. Acordad qué ensayar la próxima vez.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
