# Una conversación real con el paciente simulado

Conversación real con el agente, hecha el 16-11-2026 para esta charla y abreviada. Personaje ficticio; la residente también.

**Residente:** Quiero ensayar cómo explicar un tratamiento nuevo a una persona que tiene miedo. Soy residente de Medicina Familiar y Comunitaria, R2. Dificultad: ambivalente.

**Paciente simulado FSE:** Personaje ficticio. 58 años, conductor de autobús urbano. En una revisión le han recomendado empezar un tratamiento nuevo para una enfermedad crónica. Ha buscado información por internet y está preocupado por los efectos secundarios. Acude con dudas, miedo y sentimientos encontrados. ¿Empezamos?

**Residente:** Buenos días, soy la doctora que le atiende hoy. Antes de explicarle nada, cuénteme: ¿qué es lo que más le preocupa del tratamiento?

**Paciente simulado FSE:** Pues... los efectos secundarios, sobre todo. Yo ahora me encuentro bastante bien y me da miedo empezar algo nuevo y encontrarme peor. Además, tengo que conducir muchas horas y no puedo permitirme estar mareado o atontado.

**Residente:** Entiendo que le asuste. El fármaco actúa inhibiendo el cotransportador SGLT2 y reduce los eventos cardiovasculares. Lo mejor es que lo empiece ya.

**Paciente simulado FSE:** Perdone, doctora, pero me he perdido un poco. No sé qué es eso del... cotransportador ese que ha dicho. Yo lo que quiero saber es si me va a sentar mal, si voy a poder seguir trabajando y por qué cree que merece la pena que me lo tome si ahora mismo me encuentro bien.

**Residente:** FIN

**Paciente simulado FSE:** La simulación ha terminado. ¿Qué crees que ha ido bien y qué cambiarías?

**Residente:** Creo que empecé bien preguntando qué le preocupaba. Cambiaría la explicación: usé palabras técnicas y le metí prisa.

**Paciente simulado FSE:** Dos cosas que han funcionado: abriste con una pregunta abierta y validaste la emoción ("Entiendo que le asuste"). Dos cosas a mejorar: utilizaste tecnicismos demasiado pronto y cerraste la decisión antes de explorar la ambivalencia ("Lo mejor es que lo empiece ya"). Datos que no llegaste a descubrir: el miedo a marearse al volante y la creencia de que el tratamiento sería para toda la vida.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
