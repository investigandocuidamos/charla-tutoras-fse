# Guía para usar el paciente simulado con residentes

## Cómo funciona

1. **Elegir la conversación.** La residente dice especialidad, año, qué quiere ensayar y la dificultad.
2. **Conversar.** El agente hace de paciente: frases cortas, emociones y dos datos que solo salen si se pregunta bien.
3. **Escribir FIN.** Primero se autoevalúa la residente; después llega el feedback con cinco criterios. Y luego, el de la tutora.

## Tres condiciones para que enseñe algo

1. Un objetivo de aprendizaje del programa de la especialidad (por ejemplo, comunicar una mala noticia).
2. Práctica activa de la residente, no lectura pasiva.
3. Feedback de la tutora después, con la rúbrica.

## Límites que conviene explicar

- Sirve para ensayar, no para evaluar. No reproduce la comunicación no verbal y puede cometer errores clínicos.
- No sustituye a la práctica real supervisada ni a la simulación con personas.
- No se usan casos reales: si la residente quiere preparar una conversación que tiene pendiente, se inventa un personaje parecido.

## Qué dice la evidencia

Una revisión de alcance de 2026 con 97 estudios en una revisión de alcance de 2026 sobre pacientes virtuales generados con IA. Se usan sobre todo para comunicación y razonamiento clínico, y casi siempre se mide solo la satisfacción. Límites descritos: conversación poco natural, exceso de complacencia, imprecisión clínica.

Fang EKM, Boon Y, Ho JY, Tey N, Low MJW. BMC Med Educ. 2026;26(1). https://doi.org/10.1186/s12909-026-10028-w

## Si se usa por voz

Si el modo voz está activo en vuestro Copilot, la conversación gana realismo. La voz de la residente es un dato personal: solo con la cuenta del hospital y sin nombres.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
