# Seis conversaciones para ensayar con el paciente simulado

Sirve para ensayar, no para evaluar. No reproduce la comunicación no verbal y puede cometer errores clínicos. Todos los personajes son ficticios.

Cómo se usa: abre el agente «Paciente simulado FSE», pega el texto del escenario, completa los corchetes y escribe «empezamos». Para terminar, escribe FIN.

## 1. Acogida a una persona desconfiada

**Para trabajar:** Presentarse, generar confianza y explorar el motivo de consulta con preguntas abiertas.

**Personaje ficticio:** Hombre ficticio de 58 años que acude por primera vez, convencido de que "aquí solo dan pastillas". Responde con monosílabos al principio.

**Datos ocultos (solo para la tutora):**
- Tuvo una mala experiencia previa: se sintió juzgado en otra consulta.
- Lo que de verdad le preocupa es perder el trabajo si coge la baja.

**Texto para pegar en el agente:**

```
Quiero ensayar la acogida en una primera visita con una persona desconfiada. Soy residente de [especialidad], [R1 a R5]. Dificultad: [colaborador, ambivalente o difícil].
Personaje: hombre ficticio de 58 años que viene por primera vez y cree que "aquí solo dan pastillas". Guarda dos datos que solo salen si pregunto bien: una mala experiencia previa en otra consulta y el miedo a perder el trabajo.
```

## 2. Explicar un tratamiento a alguien con miedo

**Para trabajar:** Informar sin tecnicismos, explorar creencias y comprobar que se ha entendido.

**Personaje ficticio:** Mujer ficticia de 67 años a la que se propone un tratamiento nuevo. Ha leído en internet sobre los efectos secundarios y está asustada.

**Datos ocultos (solo para la tutora):**
- Una vecina dejó ese tratamiento "porque le sentó fatal".
- Vive sola y teme no saber tomarlo bien.

**Texto para pegar en el agente:**

```
Quiero ensayar cómo explicar un tratamiento nuevo a una persona que tiene miedo. Soy residente de [especialidad], [R1 a R5]. Dificultad: [colaborador, ambivalente o difícil].
Personaje: mujer ficticia de 67 años, asustada por lo que ha leído sobre los efectos secundarios. Guarda dos datos: la experiencia de una vecina y que vive sola y teme equivocarse con las tomas.
```

## 3. Dar una mala noticia

**Para trabajar:** Preparar la conversación, dar la información por partes, sostener el silencio y acordar el siguiente paso.

**Personaje ficticio:** Hombre ficticio de 49 años que viene a recoger un resultado y no espera nada grave. El resultado obliga a hacer más pruebas.

**Datos ocultos (solo para la tutora):**
- Su padre murió de una enfermedad parecida.
- No se lo ha contado a su pareja y no sabe cómo hacerlo.

**Texto para pegar en el agente:**

```
Quiero ensayar cómo dar una mala noticia: un resultado que obliga a hacer más pruebas. Soy residente de [especialidad], [R1 a R5]. Dificultad: [colaborador, ambivalente o difícil].
Personaje: hombre ficticio de 49 años que no espera nada grave. Guarda dos datos: un antecedente familiar que le asusta y que no se lo ha contado a su pareja.
```

## 4. Familiar enfadado por la espera

**Para trabajar:** Escuchar sin ponerse a la defensiva, reconocer la emoción, informar de lo que sí se sabe y acordar cuándo habrá más información.

**Personaje ficticio:** Hija ficticia de una paciente ingresada. Lleva horas esperando noticias y aborda a la residente en el pasillo, enfadada.

**Datos ocultos (solo para la tutora):**
- Se siente culpable por no haber traído antes a su madre.
- Es la única cuidadora y está agotada.

**Texto para pegar en el agente:**

```
Quiero ensayar una conversación con un familiar enfadado por la espera y la falta de información. Soy residente de [especialidad], [R1 a R5]. Dificultad: [colaborador, ambivalente o difícil].
Personaje: hija ficticia de una paciente ingresada, enfadada tras horas sin noticias. Guarda dos datos: la culpa por no haber consultado antes y que es la única cuidadora.
```

## 5. Entrevista motivacional ante un cambio de hábito

**Para trabajar:** Explorar la ambivalencia, reflejar, evitar el sermón y acordar un paso pequeño.

**Personaje ficticio:** Mujer ficticia de 41 años a la que se recomienda dejar de fumar. Dice que "ya lo ha intentado todo".

**Datos ocultos (solo para la tutora):**
- Fumar es su único rato para ella en todo el día.
- Lo dejó ocho meses durante un embarazo y recayó.

**Texto para pegar en el agente:**

```
Quiero ensayar una entrevista motivacional con una persona ambivalente ante dejar de fumar. Soy residente de [especialidad], [R1 a R5]. Dificultad: [colaborador, ambivalente o difícil].
Personaje: mujer ficticia de 41 años que dice que ya lo ha intentado todo. Guarda dos datos: qué función cumple el tabaco en su día y un periodo anterior en que lo dejó.
```

## 6. Explorar el malestar de alguien que lo minimiza

**Para trabajar:** Preguntar con tacto, validar, no precipitarse a aconsejar y acordar un seguimiento.

**Personaje ficticio:** Hombre ficticio de 33 años que consulta por insomnio y dice que "es solo estrés". Sonríe mucho y cambia de tema.

**Datos ocultos (solo para la tutora):**
- Lleva dos meses sin ver a sus amistades.
- Le da vergüenza hablar de cómo se siente porque "otros están peor".

**Texto para pegar en el agente:**

```
Quiero ensayar cómo explorar el malestar emocional de una persona que lo minimiza. Soy residente de [especialidad], [R1 a R5]. Dificultad: [colaborador, ambivalente o difícil].
Personaje: hombre ficticio de 33 años que consulta por insomnio y dice que es solo estrés. Guarda dos datos: aislamiento reciente y vergüenza a hablar de cómo se siente.
```

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
