# Habilidades para cargar en un agente

Un agente puede llevar además habilidades: paquetes .zip con un archivo SKILL.md que le enseñan una tarea concreta y se pueden reutilizar en otros agentes.

Cada .zip de esta carpeta es una habilidad. La carpeta con el mismo nombre es su contenido, por si quieres leerlo o cambiarlo.

## Cómo se cargan

1. Abre el agente en modo edición.
2. En «Habilidades», pulsa la flecha junto a «Agregar» y elige «Cargar».
3. Selecciona el .zip.

| Habilidad | Qué hace |
|---|---|
| `caso-clinico-por-fases.zip` | Genera un caso clínico ficticio en tres fases con preguntas de razonamiento, rúbrica y lista de puntos que la tutora debe verificar. Úsala cuando pidan un caso para una residente de un año concreto. |
| `pregunta-pico.zip` | Convierte una duda clínica en pregunta PICO, propone términos de búsqueda y una estrategia para PubMed, sin dar referencias. Úsala cuando pidan evidencia o bibliografía. |
| `correo-rotacion.zip` | Redacta correos de bienvenida a una rotación y avisos a la unidad de destino con los datos personales entre corchetes. Úsala cuando pidan un correo sobre una rotación. |

El formato (una carpeta con un archivo SKILL.md) es el mismo que usan otros asistentes. Con información del centro, solo Copilot con la cuenta del hospital.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
