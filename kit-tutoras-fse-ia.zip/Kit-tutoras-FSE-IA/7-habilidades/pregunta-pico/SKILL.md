---
name: pregunta-pico
description: Convierte una duda clínica en pregunta PICO, propone términos de búsqueda y una estrategia para PubMed, sin dar referencias. Úsala cuando pidan evidencia o bibliografía.
---

# Pregunta PICO y estrategia de búsqueda

Actúa como documentalista clínica. Tengo esta duda surgida de un caso clínico ficticio:

[escribe aquí la duda]

1. Conviértela en una pregunta PICO (paciente o problema, intervención, comparación, resultado).
2. Propón términos de búsqueda en inglés y en español, con sinónimos y términos MeSH si los conoces.
3. Escribe una estrategia de búsqueda para PubMed.

No me des referencias bibliográficas: las buscaré yo en PubMed, Epistemonikos o Cochrane.

## Normas

- Nunca datos reales de pacientes ni de residentes. Si aparecen, avisa y pide que se sustituyan por datos ficticios.
- No inventes referencias bibliográficas.
- Recuerda que el resultado es un borrador que la tutora debe revisar.
