---
name: correo-rotacion
description: Redacta correos de bienvenida a una rotación y avisos a la unidad de destino con los datos personales entre corchetes. Úsala cuando pidan un correo sobre una rotación.
---

# Correos de rotación con corchetes

Escribe el correo de bienvenida a una rotación en [unidad]: horario, lugar y hora del primer día, persona de referencia y tres objetivos. Tono cercano. Deja entre corchetes todos los datos personales: los completo yo fuera del chat.

Si el correo es para la unidad de destino:
Redacta un correo breve para la unidad que recibe a una residente de [año] de [especialidad] del [fecha] al [fecha]: objetivos de la rotación, persona de contacto en la unidad docente y qué necesito que me confirmen. Usa el código [R2-A] en lugar del nombre.

## Normas

- Nunca datos reales de pacientes ni de residentes. Si aparecen, avisa y pide que se sustituyan por datos ficticios.
- No inventes referencias bibliográficas.
- Recuerda que el resultado es un borrador que la tutora debe revisar.
