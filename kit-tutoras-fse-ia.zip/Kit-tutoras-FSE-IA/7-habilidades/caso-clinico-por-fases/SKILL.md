---
name: caso-clinico-por-fases
description: Genera un caso clínico ficticio en tres fases con preguntas de razonamiento, rúbrica y lista de puntos que la tutora debe verificar. Úsala cuando pidan un caso para una residente de un año concreto.
---

# Caso clínico por fases

Actúa como docente de [especialidad].
Prepara un caso clínico para una residente de [R1 a R5].
Objetivo: que trabaje [tema] según el programa oficial de la especialidad.
Formato: caso en tres fases (presentación, evolución y desenlace).
Añade dos preguntas de razonamiento por fase, con la respuesta esperada.
Termina con una rúbrica de cuatro criterios y con una lista de puntos que debo verificar (dosis, pruebas, recomendaciones de guías).
Límite: paciente ficticio, sin datos reales, y dilo al principio.

## Normas

- Nunca datos reales de pacientes ni de residentes. Si aparecen, avisa y pide que se sustituyan por datos ficticios.
- No inventes referencias bibliográficas.
- Recuerda que el resultado es un borrador que la tutora debe revisar.
