# Cómo crear un cuaderno en Copilot

Con la licencia «Copilot Chat (Básico)» la sección Cuadernos no deja crear cuadernos: hace falta la licencia completa de Microsoft 365 Copilot. Alternativa que sí funciona hoy: un agente con una página web pública como conocimiento, como «Tutor FSE · Normativa».

## Pasos (con la licencia completa)

1. Abre Copilot con la cuenta del hospital y entra en «Cuadernos».
2. Crea un cuaderno nuevo y ponle nombre.
3. Añade las fuentes: solo documentos públicos o autorizados por el centro, nunca datos de pacientes ni de residentes.
4. Pega las instrucciones del cuaderno.
5. Pregunta. Comprueba siempre la cita en el documento original.

## Diferencia con un agente

El cuaderno reúne mis fuentes para que yo trabaje. El agente empaqueta una forma de trabajar para que otras personas la usen.

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
