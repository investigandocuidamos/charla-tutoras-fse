# Cuaderno: Sesión clínica del trimestre

Preparar una sesión clínica o bibliográfica con residentes a partir de fuentes que yo he elegido y leído.

## Fuentes que se cargan

- Dos o tres artículos o guías de acceso abierto sobre el tema (PDF)
- El caso clínico ficticio ya revisado
- El apartado del programa oficial que justifica el objetivo de aprendizaje

## Instrucciones del cuaderno

```
Trabaja solo con las fuentes de este cuaderno y di de cuál sale cada afirmación. Si las fuentes discrepan, muéstralo. No añadas referencias que no estén cargadas. Todo lo que propongas es un borrador para revisar.
```

## Preguntas para empezar

```
Resume en cinco puntos qué dicen estas fuentes sobre el tema y de cuál sale cada punto.
```

```
Propón un guion de sesión de 30 minutos con tres preguntas para que participen las residentes.
```

```
Genera cinco preguntas tipo test con la explicación y la fuente de cada respuesta.
```

```
¿En qué discrepan las fuentes entre sí y qué habría que comprobar?
```

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
