# Cuaderno: Tutoría FSE · Normativa y documentos

Tener a mano lo que regula la tutoría y preguntar sobre ello con la respuesta ligada al texto.

## Fuentes que se cargan

- Real Decreto 183/2008 (BOE, documento público)
- Programa oficial de tu especialidad (BOE, documento público)
- Guía o itinerario formativo de tu unidad docente, solo si el centro lo autoriza
- Plantillas vacías de entrevista y de informe, sin datos

## Instrucciones del cuaderno

```
Responde solo con lo que conste en las fuentes de este cuaderno. Cita siempre el documento y el artículo o apartado, y copia la frase literal entre comillas. Si algo no está en las fuentes, dilo. No des interpretaciones jurídicas: señala dónde hay que comprobarlo.
```

## Preguntas para empezar

```
¿Qué dice el real decreto sobre las entrevistas tutora-residente? Cita el artículo y la frase literal.
```

```
Compara en una tabla los objetivos del programa oficial para R1 y para R2.
```

```
Hazme una lista de comprobación de lo que tiene que constar en el libro del residente según estas fuentes.
```

```
Prepara el orden del día de la entrevista del segundo trimestre con los objetivos del programa para R2.
```

---
Inteligencia artificial en la docencia de residentes. Marta Domínguez del Campo, Parc Sanitari Sant Joan de Déu. Todos los casos, nombres y conversaciones son ficticios.
